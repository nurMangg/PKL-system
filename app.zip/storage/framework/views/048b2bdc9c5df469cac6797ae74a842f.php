<?php $__env->startSection('title'); ?>
    Guru
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
    <div class="pagetitle">
        <h1>Guru</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Guru</li>
                <li class="breadcrumb-item active">Edit</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <h5>Edit Data Guru</h5>
            </div>
        </div>
        <div class="card-body">
            <div class="container mt-3">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('guru.update', $guru->id_guru)); ?>" method="POST" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="id_guru" class="form-label">ID Guru</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['id_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_guru" name="id_guru" value="<?php echo e(old('id_guru', $guru->id_guru)); ?>" required maxlength="15">
                        <div class="invalid-feedback">
                            ID Guru wajib diisi dan maksimal 15 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" value="<?php echo e(old('nama', $guru->nama)); ?>" required maxlength="50">
                        <div class="invalid-feedback">
                            Nama wajib diisi dan maksimal 50 karakter.
                        </div>
                    </div>

                    <!-- Gender Radio Buttons -->
                    <div class="mb-3">
                        <label for="gender">Gender</label>
                        <div>
                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="gender"
                                        id="gender_<?php echo e($g); ?>" value="<?php echo e($g); ?>"
                                        <?php echo e(old('gender', $guru->gender) == $g ? 'checked' : ''); ?> required>
                                    <label class="form-check-label" for="gender_<?php echo e($g); ?>"><?php echo e($g); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="invalid-feedback">
                            Gender wajib dipilih.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="no_kontak" class="form-label">Nomor Kontak</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['no_kontak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_kontak" name="no_kontak" value="<?php echo e(old('no_kontak', $guru->no_kontak)); ?>" required maxlength="14">
                        <div class="invalid-feedback">
                            Nomor kontak wajib diisi dan maksimal 14 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email', $guru->email)); ?>" required maxlength="35">
                        <div class="invalid-feedback">
                            Email wajib diisi dan maksimal 35 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" name="alamat" maxlength="100"><?php echo e(old('alamat', $guru->alamat)); ?></textarea>
                        <div class="invalid-feedback">
                            Alamat maksimal 100 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="id_jurusan" class="form-label">Jurusan</label>
                        <option value="">Pilih</option>
                        <select class="form-select <?php $__errorArgs = ['id_jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_jurusan" name="id_jurusan" required>
                            <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_jurusan); ?>" <?php echo e(old('id_jurusan', $guru->id_jurusan) == $item->id_jurusan ? 'selected' : ''); ?>><?php echo e($item->jurusan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Jurusan wajib dipilih.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u904290797/domains/pkl.smkkarbak.my.id/pengajuan-PKL/resources/views/guru/edit.blade.php ENDPATH**/ ?>