<?php $__env->startSection('content'); ?>
<h1>Edit Pengajuan Surat PKL</h1>
<form action="<?php echo e(route('pengajuan.update', $pengajuan->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label>Nama Siswa:</label>
    <input type="text" name="nama_siswa" value="<?php echo e($pengajuan->nama_siswa); ?>" required>
    <label>Kelas:</label>
    <input type="text" name="kelas" value="<?php echo e($pengajuan->kelas); ?>" required>
    <label>Perusahaan Tujuan:</label>
    <input type="text" name="perusahaan_tujuan" value="<?php echo e($pengajuan->perusahaan_tujuan); ?>" required>
    <label>Tanggal Pengajuan:</label>
    <input type="date" name="tanggal_pengajuan" value="<?php echo e($pengajuan->tanggal_pengajuan); ?>" required>
    <label>Status:</label>
    <select name="status">
        <option value="Pending" <?php echo e($pengajuan->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
        <option value="Disetujui" <?php echo e($pengajuan->status == 'Disetujui' ? 'selected' : ''); ?>>Disetujui</option>
        <option value="Ditolak" <?php echo e($pengajuan->status == 'Ditolak' ? 'selected' : ''); ?>>Ditolak</option>
    </select>
    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/siswa/pengajuan/edit.blade.php ENDPATH**/ ?>