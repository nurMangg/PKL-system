<?php $__env->startSection('title'); ?>
    Dudi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
    <div class="pagetitle">
        <h1>Dudi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dudi</li>
                <li class="breadcrumb-item active">Tambah Baru</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <h5>Tambah Data Dudi</h5>
            </div>
        </div>
        <div class="card-body">
            <div class="container mt-3">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('dudi.store')); ?>" method="POST" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama DUDI</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" required maxlength="30">
                        <div class="invalid-feedback">
                            Nama wajib diisi dan maksimal 30 karakter.
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="nama_pimpinan" class="form-label">Nama Pimpinan</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama_pimpinan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_pimpinan" name="nama_pimpinan" value="<?php echo e(old('nama_pimpinan')); ?>" required maxlength="50">
                        <div class="invalid-feedback">
                            Nama wajib diisi dan maksimal 50 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="no_kontak" class="form-label">Nomor Kontak</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['no_kontak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_kontak" name="no_kontak" value="<?php echo e(old('no_kontak')); ?>" required maxlength="14">
                        <div class="invalid-feedback">
                            Nomor kontak wajib diisi dan maksimal 14 karakter.
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" name="alamat" maxlength="100" required><?php echo e(old('alamat')); ?></textarea>
                        <div class="invalid-feedback">
                            Alamat maksimal 100 karakter.
                        </div>
                    </div>

                    <div id="map" style="height: 400px;"></div>

                    <div class="mb-3 mt-3">
                        <label for="latitude" class="form-label">Latitude</label>
                        <input type="text" class="form-control" id="latitude1" readonly required>
                        <input type="hidden" id="latitude" name="latitude">
                    </div>

                    <div class="mb-3">
                        <label for="longitude" class="form-label">Longitude</label>
                        <input type="text" class="form-control" id="longitude1" readonly required>
                        <input type="hidden" id="longitude" name="longitude">
                    </div>

                    <div class="mb-3">
                        <label for="radius" class="form-label">Radius (meter)</label>
                        <input type="number" class="form-control" id="radius" name="radius" placeholder="Masukkan radius dalam meter" required value="8">
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets')); ?>/vendor/leaflet/leaflet.js"></script>
<script>
    // Inisialisasi peta
    var map = L.map('map').setView([-6.982814303476982, 109.13654360065006], 13); // Koordinat awal (Surabaya)

    // Tile Layer dari OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    }).addTo(map);

    var marker;
    var radiusCircle;

    // Event klik di peta untuk mendapatkan latitude dan longitude
    map.on('click', function(e) {
        var lat = e.latlng.lat;
        var lng = e.latlng.lng;

        // Tampilkan marker di lokasi yang diklik
        if (marker) {
            map.removeLayer(marker);
        }
        marker = L.marker([lat, lng]).addTo(map);

        // Masukkan koordinat ke input field
        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;
        document.getElementById('latitude1').value = lat;
        document.getElementById('longitude1').value = lng;

        // Tambahkan lingkaran radius jika radius diinput
        var radius = document.getElementById('radius').value;
        if (radius) {
            // Hapus lingkaran radius sebelumnya jika ada
            if (radiusCircle) {
                map.removeLayer(radiusCircle);
            }
            radiusCircle = L.circle([lat, lng], {
                color: 'blue',
                fillColor: '#cce5ff',
                fillOpacity: 0.4,
                radius: parseFloat(radius) // Radius dalam meter
            }).addTo(map);
        }
    });

    // Event perubahan pada input radius
    document.getElementById('radius').addEventListener('input', function() {
        var radius = this.value;
        if (marker) {
            // Hapus lingkaran radius sebelumnya jika ada
            if (radiusCircle) {
                map.removeLayer(radiusCircle);
            }
            radiusCircle = L.circle([marker.getLatLng().lat, marker.getLatLng().lng], {
                color: 'blue',
                fillColor: '#cce5ff',
                fillOpacity: 0.4,
                radius: parseFloat(radius) // Radius dalam meter
            }).addTo(map);
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets')); ?>/vendor/leaflet/leaflet.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u904290797/domains/pkl.smkkarbak.my.id/pengajuan-PKL/resources/views/dudi/dudi/create.blade.php ENDPATH**/ ?>