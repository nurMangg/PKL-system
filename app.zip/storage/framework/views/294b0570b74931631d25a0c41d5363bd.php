<?php $__env->startSection('title'); ?>
    Buat Penilaian PKL
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
<div class="pagetitle">
    <h1>Buat Penilaian PKL</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">PKL</li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('penilaian.index')); ?>">Penilaian</a></li>
            <li class="breadcrumb-item active">Buat Penilaian</li>
        </ol>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <?php echo e(session('warning')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Data Siswa</h5>
        <div class="row mb-4">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">NIS</th>
                        <td><?php echo e($siswa->nis); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Siswa</th>
                        <td><?php echo e($siswa->nama); ?></td>
                    </tr>
                    <tr>
                        <th width="30%">Jurusan</th>
                        <td><?php echo e($siswa->jurusan->jurusan ?? 'N/A'); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <form action="<?php echo e(route('penilaian.store')); ?>" method="POST" id="penilaianForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_siswa" value="<?php echo e($siswa->nis); ?>">

            <div class="row mb-3 mt-4">
                <div class="col-md-12">
                    <label for="projectpkl" class="form-label">Masukkan Judul Project PKL</label>
                    <input class="form-control" id="projectpkl" name="projectpkl"
                              placeholder=""></input>
                </div>
            </div>

            <h5 class="card-title">Form Penilaian</h5>
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i>
                <strong>Petunjuk Penilaian:</strong><br>
                • Pilih Ya/Tidak untuk setiap indikator penilaian
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th width="60%">Indikator Penilaian</th>
                            <th width="20%">Ketercapaian (Ya/Tidak)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $template->mainItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td><strong><?php echo e($no++); ?></strong></td>
                                    <td>
                                        <strong><?php echo e($mainItem->indikator); ?></strong>
                                    </td>
                                    <td>
                                        <input type="number"
                                            name="nilai[<?php echo e($mainItem->id); ?>]"
                                            class="form-control main-indicator-value"
                                            readonly
                                            hidden
                                            data-main-id="<?php echo e($mainItem->id); ?>"
                                            placeholder="Dihitung otomatis">
                                    </td>
                                </tr>

                                
                                <?php if($mainItem->children->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $mainItem->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td></td>
                                            <td class="ps-3">
                                                <?php echo e($subItem->indikator); ?>

                                            </td>
                                            <td>
                                                <?php if($subItem->level3Children->isNotEmpty()): ?>
                                                    
                                                    <input type="number"
                                                        class="form-control sub-indicator-value"
                                                        readonly
                                                        hidden
                                                        data-sub-id="<?php echo e($subItem->id); ?>"
                                                        data-main-id="<?php echo e($mainItem->id); ?>"
                                                        placeholder="Dihitung dari Level 3">
                                                <?php else: ?>
                                                    
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input nilai-radio sub-direct-assessment"
                                                               type="radio"
                                                               name="nilai-sub[<?php echo e($subItem->id); ?>]"
                                                               value="1"
                                                               data-sub-id="<?php echo e($subItem->id); ?>"
                                                               data-main-id="<?php echo e($mainItem->id); ?>">
                                                        <label class="form-check-label">Ya</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input nilai-radio sub-direct-assessment"
                                                               type="radio"
                                                               name="nilai-sub[<?php echo e($subItem->id); ?>]"
                                                               value="0"
                                                               data-sub-id="<?php echo e($subItem->id); ?>"
                                                               data-main-id="<?php echo e($mainItem->id); ?>">
                                                        <label class="form-check-label">Tidak</label>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                        
                                        <?php if($subItem->level3Children->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $subItem->level3Children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td></td>
                                                    <td class="ps-5">
                                                        <?php echo e($subSubItem->indikator); ?>

                                                    </td>
                                                    <td>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input nilai-radio level3-assessment"
                                                                   type="radio"
                                                                   name="nilai-sub[<?php echo e($subSubItem->id); ?>]"
                                                                   value="1"
                                                                   data-subsub-id="<?php echo e($subSubItem->id); ?>"
                                                                   data-sub-id="<?php echo e($subItem->id); ?>"
                                                                   data-main-id="<?php echo e($mainItem->id); ?>">
                                                            <label class="form-check-label">Ya</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input nilai-radio level3-assessment"
                                                                   type="radio"
                                                                   name="nilai-sub[<?php echo e($subSubItem->id); ?>]"
                                                                   value="0"
                                                                   data-subsub-id="<?php echo e($subSubItem->id); ?>"
                                                                   data-sub-id="<?php echo e($subItem->id); ?>"
                                                                   data-main-id="<?php echo e($mainItem->id); ?>">
                                                            <label class="form-check-label">Tidak</label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="row mb-3 mt-4">
                <div class="col-md-12">
                    <label for="catatan" class="form-label">Catatan Penilaian</label>
                    <textarea class="form-control" id="catatan" name="catatan" rows="4"
                              placeholder="Masukkan catatan atau komentar tambahan untuk penilaian ini..."></textarea>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 text-end">
                    <a href="<?php echo e(route('penilaian.index')); ?>" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary" id="submitBtn" disabled>Simpan Penilaian</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    // Function to update keterangan based on value
    function updateKeterangan(elementId, value) {
        const ketElement = $('#' + elementId);
        if (value === 1 || value === '1') {
            ketElement.removeClass('bg-secondary bg-danger').addClass('bg-success').text('Tercapai');
        } else if (value === 0 || value === '0') {
            ketElement.removeClass('bg-secondary bg-success').addClass('bg-danger').text('Tidak Tercapai');
        } else {
            ketElement.removeClass('bg-success bg-danger').addClass('bg-secondary').text('Menunggu');
        }
    }

    // Function to calculate Level 2 from Level 3
    function calculateLevel2(subId) {
        let total = 0;
        let count = 0;

        $(`input[data-sub-id="${subId}"].level3-assessment:checked`).each(function() {
            total += parseInt($(this).val());
            count++;
        });

        // Check if all level 3 items for this sub are assessed
        const totalLevel3Items = $(`input[data-sub-id="${subId}"].level3-assessment`).length / 2; // Divided by 2 because of Ya/Tidak

        if (count === totalLevel3Items) {
            // All level 3 items assessed
            const level2Value = (total === count) ? 1 : 0; // All must be 1 for level 2 to be 1
            $(`input[data-sub-id="${subId}"].sub-indicator-value`).val(level2Value);
            updateKeterangan(`ket-sub-${subId}`, level2Value);

            // Calculate main indicator
            const mainId = $(`input[data-sub-id="${subId}"]`).first().data('main-id');
            calculateMainIndicator(mainId);
        } else {
            // Not all assessed yet
            $(`input[data-sub-id="${subId}"].sub-indicator-value`).val('');
            updateKeterangan(`ket-sub-${subId}`, null);
        }
    }

    // Function to calculate Main Indicator from Sub Indicators
    function calculateMainIndicator(mainId) {
        let total = 0;
        let count = 0;

        // Check direct sub assessments
        $(`input[data-main-id="${mainId}"].sub-direct-assessment:checked`).each(function() {
            total += parseInt($(this).val());
            count++;
        });

        // Check calculated sub values
        $(`input[data-main-id="${mainId}"].sub-indicator-value`).each(function() {
            const val = $(this).val();
            if (val !== '') {
                total += parseInt(val);
                count++;
            }
        });

        // Check total sub indicators for this main
        const totalSubItems = $(`input[data-main-id="${mainId}"].sub-direct-assessment`).length / 2 +
                             $(`input[data-main-id="${mainId}"].sub-indicator-value`).length;

        if (count === totalSubItems) {
            // All sub indicators assessed
            const percentage = (count > 0) ? (total / count) * 100 : 0;
            $(`input[data-main-id="${mainId}"].main-indicator-value`).val(percentage.toFixed(0));

            if (percentage >= 80) {
                updateKeterangan(`ket-main-${mainId}`, 1);
            } else {
                updateKeterangan(`ket-main-${mainId}`, 0);
            }
        } else {
            $(`input[data-main-id="${mainId}"].main-indicator-value`).val('');
            updateKeterangan(`ket-main-${mainId}`, null);
        }

        checkFormCompletion();
    }

    // Function to check if form is complete
    function checkFormCompletion() {
        let allAssessed = true;

        // Check if all assessable items are completed
        $('.level3-assessment, .sub-direct-assessment').each(function() {
            const name = $(this).attr('name');
            if (!$(`input[name="${name}"]:checked`).length) {
                allAssessed = false;
                return false;
            }
        });

        $('#submitBtn').prop('disabled', !allAssessed);
    }

    // Event handlers
    $('.level3-assessment').change(function() {
        const subSubId = $(this).data('subsub-id');
        const subId = $(this).data('sub-id');
        const value = $(this).val();

        updateKeterangan(`ket-subsub-${subSubId}`, value);
        calculateLevel2(subId);
    });

    $('.sub-direct-assessment').change(function() {
        const subId = $(this).data('sub-id');
        const mainId = $(this).data('main-id');
        const value = $(this).val();

        updateKeterangan(`ket-sub-${subId}`, value);
        calculateMainIndicator(mainId);
    });

    // Initial form completion check
    checkFormCompletion();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/pkl/penilaian/create.blade.php ENDPATH**/ ?>