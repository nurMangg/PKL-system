<?php $__env->startSection('content'); ?>
<h1>Tambah Pengajuan Surat PKL</h1>
<form action="<?php echo e(route('pengajuan.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Nama Siswa:</label>
    <input type="text" name="nama_siswa" required>
    <label>Kelas:</label>
    <input type="text" name="kelas" required>
    <label>Perusahaan Tujuan:</label>
    <input type="text" name="perusahaan_tujuan" required>
    <label>Tanggal Pengajuan:</label>
    <input type="date" name="tanggal_pengajuan" required>
    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/siswa/pengajuan/create.blade.php ENDPATH**/ ?>