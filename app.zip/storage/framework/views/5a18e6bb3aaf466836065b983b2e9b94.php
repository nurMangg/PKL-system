<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="ida3f070c2edcbb" a='{"t":"r","v":"1.2","lang":"id","locs":[1656],"ssot":"c","sics":"ds","cbkg":"rgb(69,90,100)","cfnt":"#FFFFFF","codd":"rgb(84,110,122)","cont":"#E0E0E0"}'>Sumber Data Cuaca: <a href="https://cuacalab.id/cuaca_tegal/2_minggu/">cuaca Tegal 15 hari</a></div><script async src="https://static1.cuacalab.id/widgetjs/?id=ida3f070c2edcbb"></script>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u904290797/domains/sobsob.baruhajayaabadi.com/pengajuan-PKL/resources/views/dashboard/index.blade.php ENDPATH**/ ?>