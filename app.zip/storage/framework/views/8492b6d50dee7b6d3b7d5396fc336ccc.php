<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD File Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Upload File Balasan Dudi</h1>

        <!-- Form Upload -->
        <div class="card mb-4">
            <div class="card-body">
                <form action="<?php echo e(route('d.upload')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="file" class="form-label">Pilih File:</label>
                        <input type="file" class="form-control" name="file" id="file" accept=".pdf,.doc,.docx,.png,." required>
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </form>
            </div>
        </div>

        <!-- Daftar File -->
        <h2 class="mb-3">Daftar File</h2>
        <?php if($files->isNotEmpty()): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama File</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($file->file_name); ?></td>
                            <td><?php echo e($file->uploaded_at); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <a href="<?php echo e(route('d.edit', $file->id)); ?>" class="btn btn-warning">Edit</a>

                                    <a href="<?php echo e(route('d.delete', $file->id)); ?>" class="btn btn-danger">Hapus</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-muted">Tidak ada file yang diunggah.</p>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/siswa/upload-surat/index.blade.php ENDPATH**/ ?>