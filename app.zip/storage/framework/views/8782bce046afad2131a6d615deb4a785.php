<?php $__env->startSection('title'); ?>
    Daftar Penilaian PKL
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
<div class="pagetitle">
    <h1>Daftar Penilaian PKL</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">PKL</li>
            <li class="breadcrumb-item active">Penilaian</li>
        </ol>
    </nav>
</div><!-- End Page Title -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <?php echo e(session('warning')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title">Daftar Siswa PKL Tahun Akademik <?php echo e($thnAkademik->tahun_akademik ?? 'N/A'); ?></h5>
            
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="jurusan_filter">Jurusan</label>
                    <select id="jurusan_filter" class="form-select">
                        <option value="">Semua Jurusan</option>
                        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jurusan->id_jurusan); ?>"><?php echo e($jurusan->jurusan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered" id="penilaianTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Jurusan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data akan diisi oleh DataTables -->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets')); ?>/vendor/dataTables/dataTables.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dataTables/dataTables.bootstrap5.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/select2/js/select2.min.js"></script>
<script>
    $(function() {
        var table = $('#penilaianTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('penilaian.data')); ?>",
                data: function(d) {
                    d.jurusan_id = $('#jurusan_filter').val();
                }
            },
            columns: [
                {
                    data: 'id',
                    name: 'id',
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    }
                },
                { data: 'nis', name: 'nis' },
                { data: 'nama', name: 'nama' },
                { data: 'jurusan.singkatan', name: 'jurusan.singkatan', defaultContent: 'N/A' },
                { data: 'status_penilaian', name: 'status_penilaian', orderable: false, searchable: false },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ],
            order: [[2, 'asc']]
        });

        // Filter berdasarkan jurusan
        $('#jurusan_filter').change(function() {
            table.draw();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/pkl/penilaian/index.blade.php ENDPATH**/ ?>