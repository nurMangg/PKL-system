<?php $__env->startSection('content'); ?>
<h1>Daftar Pengajuan Surat PKL</h1>
<a href="<?php echo e(route('pengajuan.create')); ?>">Tambah Pengajuan</a>
<table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Siswa</th>
            <th>Kelas</th>
            <th>Perusahaan Tujuan</th>
            <th>Tanggal Pengajuan</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($item->nim); ?></td>
            <td><?php echo e($item->kelas); ?></td>
            <td><?php echo e($item->perusahaan_tujuan); ?></td>
            <td><?php echo e($item->tanggal_pengajuan); ?></td>
            <td><?php echo e($item->status); ?></td>
            <td>
                <a href="<?php echo e(route('pengajuan.edit', $item->id)); ?>">Edit</a>
                <form action="<?php echo e(route('pengajuan.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/siswa/pengajuan/index.blade.php ENDPATH**/ ?>