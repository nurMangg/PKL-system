<?php $__env->startSection('title'); ?>
    Detail Penilaian PKL
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagetitle'); ?>
<div class="pagetitle">
    <h1>Detail Penilaian PKL</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">PKL</li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('penilaian.index')); ?>">Penilaian</a></li>
            <li class="breadcrumb-item active">Detail Penilaian</li>
        </ol>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title">Data Siswa</h5>
            <div>
                <a href="<?php echo e(route('penilaian.edit', $siswa->nis)); ?>" class="btn btn-warning">
                    <i class="bi bi-pencil"></i> Edit Penilaian
                </a>
                <a href="<?php echo e(route('penilaian.print', $siswa->nis)); ?>" class="btn btn-primary" target="_blank">
                    <i class="bi bi-printer"></i> Cetak Penilaian
                </a>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">NIS</th>
                        <td><?php echo e($siswa->nis); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Siswa</th>
                        <td><?php echo e($siswa->nama); ?></td>
                    </tr>
                    <tr>
                        <th>Kelas</th>
                        <td><?php echo e($siswa->kelas ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Judul Project PKL</th>
                        <td><?php echo e($projectpkl->projectpkl ?? 'N/A'); ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">Jurusan</th>
                        <td><?php echo e($siswa->jurusan->jurusan ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Guru Pembimbing</th>
                        <td><?php echo e($penempatan->guru->nama ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Nilai Akhir</th>
                        <td>
                            <span class="badge bg-primary fs-6"><?php echo e(number_format($nilaiAkhir, 2)); ?></span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <h5 class="card-title">Hasil Penilaian</h5>

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th width="5%">No</th>
                        <th width="60%">Indikator Penilaian</th>
                        <th width="20%">Nilai/Status</th>
                        <th width="15%">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $mainIndicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainIndicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr class="table-primary">
                            <td><strong><?php echo e($no++); ?></strong></td>
                            <td>
                                <strong><?php echo e($mainIndicator->indikator); ?></strong>
                            </td>
                            <td class="text-center">
                                <?php if($mainIndicator->penilaian): ?>
                                    <span class="badge bg-success fs-6">
                                        <?php echo e(number_format($mainIndicator->penilaian->nilai_instruktur, 0)); ?>%
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Tidak Dinilai</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($mainIndicator->penilaian): ?>
                                    <?php echo e(getNilaiKeterangan($mainIndicator->penilaian->nilai_instruktur)); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>

                        
                        <?php if($mainIndicator->children && $mainIndicator->children->count() > 0): ?>
                            <?php $__currentLoopData = $mainIndicator->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subIndicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td></td>
                                    <td class="ps-3">
                                        <span class="badge bg-info me-2">Level 2</span>
                                        <?php echo e($subIndicator->indikator); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($subIndicator->is_nilai == 1): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Tidak</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($subIndicator->is_nilai == 1): ?>
                                            Tercapai
                                        <?php else: ?>
                                            Tidak Tercapai
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                
                                <?php if($subIndicator->level3Children && $subIndicator->level3Children->count() > 0): ?>
                                    <?php $__currentLoopData = $subIndicator->level3Children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subSubIndicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="table-warning">
                                            <td></td>
                                            <td class="ps-5">
                                                <span class="badge bg-warning me-2">Level 3</span>
                                                <?php echo e($subSubIndicator->indikator); ?>

                                            </td>
                                            <td class="text-center">
                                                <?php if($subSubIndicator->is_nilai == 1): ?>
                                                    <span class="badge bg-success">Ya</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Tidak</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($subSubIndicator->is_nilai == 1): ?>
                                                    Tercapai
                                                <?php else: ?>
                                                    Tidak Tercapai
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ringkasan Nilai Main Indicator</h5>
                        <table class="table table-sm">
                            <?php $__currentLoopData = $mainIndicatorPenilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($penilaian->prgObsvr->indikator ?? 'N/A'); ?></td>
                                    <td class="text-end">
                                        <span class="badge bg-primary">
                                            <?php echo e(number_format($penilaian->nilai_instruktur, 0)); ?>%
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-primary">
                                <th>Nilai Akhir (Rata-rata)</th>
                                <th class="text-end">
                                    <span class="badge bg-success fs-6">
                                        <?php echo e(number_format($nilaiAkhir, 2)); ?>%
                                    </span>
                                </th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Catatan Penilaian</h5>
                        <p><?php echo e($catatanText ?: 'Tidak ada catatan'); ?></p>

                        <h6 class="mt-3">Informasi Penilaian</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Dinilai Oleh</th>
                                <td><?php echo e($mainIndicatorPenilaian->first()->created_by ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Tanggal Penilaian</th>
                                <td><?php echo e($mainIndicatorPenilaian->first() ? date('d-m-Y H:i', strtotime($mainIndicatorPenilaian->first()->created_at)) : 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php
function getNilaiKeterangan($nilai) {
    if ($nilai >= 86) {
        return 'Sangat Baik (A)';
    } elseif ($nilai >= 71) {
        return 'Baik (B)';
    } elseif ($nilai >= 56) {
        return 'Cukup Baik (C)';
    } else {
        return 'Perlu Perbaikan (D)';
    }
}
?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u904290797/domains/sobsob.baruhajayaabadi.com/pengajuan-PKL/resources/views/pkl/penilaian/show.blade.php ENDPATH**/ ?>