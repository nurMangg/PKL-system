<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1>Detail File</h1>
    <table class="table table-bordered">
        <tr>
            <th>Nama File</th>
            <td><?php echo e($file->file_name); ?></td>
        </tr>
        <tr>
            <th>Pengunggah</th>
            <td><?php echo e($file->uploader_name ?? 'Tidak Diketahui'); ?></td>
        </tr>
        <tr>
            <th>Tanggal Upload</th>
            <td><?php echo e($file->uploaded_at->format('d M Y, H:i')); ?></td>
        </tr>
        <tr>
            <th>Lokasi Penyimpanan</th>
            <td><?php echo e($file->file_path); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('guru.files')); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pengajuan-PKL/resources/views/siswa/upload-surat/lihat.blade.php ENDPATH**/ ?>